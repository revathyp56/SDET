package makemytrip.com;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class MakeMyTrip {

	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
      
      driver.get("https://makemytrip.com");
      Thread.sleep(3000);
     // Actions act = new Actions(driver);
		//act.moveByOffset(913, 477).contextClick().build().perform();
      driver.findElement(By.xpath("//div[@class='makeFlex'][1]//ul")).click();
      driver.findElement(By.xpath("//div[@class='makeFlex']//ul//li[2]")).click();
      driver.findElement(By.xpath("//*[contains(@id,'fromCity')]")).click();
     // driver.findElement(By.xpath("//div[@class='fsw_inputBox searchCity inactiveWidget']/label")).click();
       Thread.sleep(3000);
      WebElement from= driver.findElement(By.xpath("//div[@class='hsw_autocomplePopup autoSuggestPlugin ']/div/input"));
      Thread.sleep(2000);
      from.sendKeys("Kochi");
      Thread.sleep(2000);
      from.sendKeys(Keys.ARROW_DOWN);
      Thread.sleep(2000);
      from.sendKeys(Keys.ENTER);
      Thread.sleep(2000);
     WebElement To=driver.findElement(By.xpath("//*[contains(@placeholder,'To')]"));
     Thread.sleep(2000);
     To.sendKeys("Chennai");
     Thread.sleep(2000);
     To.sendKeys(Keys.ARROW_DOWN);
     Thread.sleep(2000);
     To.sendKeys(Keys.ENTER);
     Thread.sleep(2000);
     driver.findElement(By.xpath("//div[@class='DayPicker-Week']/div[@aria-label='Sun Jul 25 2021']")).click();
     Thread.sleep(2000);
     driver.findElement(By.xpath("//div[@class='DayPicker-Week']/div[@aria-label='Mon Aug 02 2021']")).click();
     driver.findElement(By.xpath("//*[text()='Search']")).click();
    
     
     String F_arrow_direction = driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/span[1]/span[2]")).getAttribute("class");
     if(!F_arrow_direction.contains("up"))
         driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/label[1]/div[1]/div[2]/div[2]/span[1]/span[1]/span[1]")).click();

     Thread.sleep(2000);//Sleeping 2 seconds to avoid the StaleElementReferenceException

     //Now retrieve the price of the First flight, as it is the lowest fare
     String F_lowest_fare = driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/label[1]/div[1]")).getText();
     System.out.println("\nLowest fare is: "+ F_lowest_fare);
     
     String T_arrow_direction = driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[4]/span[1]/span[2]")).getAttribute("class");
     if(!T_arrow_direction.contains("up"))
         driver.findElement(By.xpath("//div[@class='splitVw']/div[2]/div[2]/div/label[1]/div/div[2]/div[2]/span")).click();

     Thread.sleep(2000);//Sleeping 2 seconds to avoid the StaleElementReferenceException

     //Now retrieve the price of the First flight, as it is the lowest fare
     String T_lowest_fare = driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/label[1]/div[1]")).getText();
     System.out.println("\nLowest fare is: "+ T_lowest_fare);
     
    driver.findElement(By.xpath("//button[contains(@class,'splitFooterButton button buttonPrimary buttonBig ')]")).click();
    Thread.sleep(2000);
     
    driver.findElement(By.xpath("//button[contains(text(),'Continue')]")).click();
    //Thread.sleep(2000);
   // WebDriverWait wait = new WebDriverWait(driver,30);
    
   // wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[contains(text(),'Review your booking')]")));
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    String review=driver.findElement(By.xpath("//h4[contains(text(),'Review your booking')]")).getText();
    //String review= driver.findElement(By.xpath("//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]']")).getText();
    System.out.println("Flight details" + review);
    

}
}
